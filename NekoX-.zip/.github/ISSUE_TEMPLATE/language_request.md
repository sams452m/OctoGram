---
name: Language builtin request
about: Request to amend the built-in translation
title: ''
labels: ''
assignees: ''

---

**Language (please complete the following information):**
 - Language: [e.g. en_US]
 - Pack Link: [e.g. https://translations.telegram.org/en/]

**If the language has already been built in, please describe the reason for the replacement:**
e.g. The language pack is no longer maintained / The original meaning is modified